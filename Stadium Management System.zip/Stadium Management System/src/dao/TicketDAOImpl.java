package dao;

import model.Ticket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TicketDAOImpl implements TicketDAO {
    @Override
    public void addTicket(Ticket ticket) {
        String sql = "INSERT INTO ticket (event_id, seat_number, price, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, ticket.getEventId());
            stmt.setString(2, ticket.getSeatNumber());
            stmt.setDouble(3, ticket.getPrice());
            stmt.setString(4, ticket.getStatus());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error adding ticket: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateTicket(Ticket ticket) {
        String sql = "UPDATE ticket SET event_id = ?, seat_number = ?, price = ?, status = ? WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, ticket.getEventId());
            stmt.setString(2, ticket.getSeatNumber());
            stmt.setDouble(3, ticket.getPrice());
            stmt.setString(4, ticket.getStatus());
            stmt.setInt(5, ticket.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new RuntimeException("Ticket with ID " + ticket.getId() + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error updating ticket: " + e.getMessage(), e);
        }
    }

    @Override
    public void deleteTicket(int ticketId) {
        String sql = "DELETE FROM ticket WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, ticketId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new RuntimeException("Ticket with ID " + ticketId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting ticket: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Ticket> getAllTickets() {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM ticket";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Ticket ticket = new Ticket(
                    rs.getInt("ticket_id"),
                    rs.getInt("event_id"),
                    rs.getString("seat_number"),
                    rs.getDouble("price"),
                    rs.getString("status")
                );
                tickets.add(ticket);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching tickets: " + e.getMessage(), e);
        }
        return tickets;
    }
}