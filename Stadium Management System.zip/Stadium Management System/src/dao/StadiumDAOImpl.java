package dao;

import model.Stadium;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StadiumDAOImpl implements StadiumDAO {
    @Override
    public void addStadium(Stadium stadium) {
        String sql = "INSERT INTO stadium (name, location, capacity) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, stadium.getName());
            pstmt.setString(2, stadium.getLocation());
            pstmt.setInt(3, stadium.getCapacity());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error adding stadium: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateStadium(Stadium stadium) {
        String sql = "UPDATE stadium SET name = ?, location = ?, capacity = ? WHERE stadium_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, stadium.getName());
            pstmt.setString(2, stadium.getLocation());
            pstmt.setInt(3, stadium.getCapacity());
            pstmt.setInt(4, stadium.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating stadium: " + e.getMessage(), e);
        }
    }

    @Override
    public void deleteStadium(int stadiumId) {
        String sql = "DELETE FROM stadium WHERE stadium_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, stadiumId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting stadium: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Stadium> getAllStadiums() {
        List<Stadium> stadiums = new ArrayList<>();
        String sql = "SELECT * FROM stadium";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Stadium stadium = new Stadium(
                    rs.getInt("stadium_id"),
                    rs.getString("name"),
                    rs.getString("location"),
                    rs.getInt("capacity")
                );
                stadiums.add(stadium);
            }
            System.out.println("Number of stadiums fetched: " + stadiums.size()); // Debug line
        } catch (SQLException e) {
            throw new RuntimeException("Error fetching stadiums: " + e.getMessage(), e);
        }
        return stadiums;
    }
}