package dao;

import model.Stadium;
import java.util.List;

public interface StadiumDAO {
    void addStadium(Stadium stadium);
    void updateStadium(Stadium stadium);
    void deleteStadium(int stadiumId);
    List<Stadium> getAllStadiums();
}