package dao;

import model.Ticket;
import java.util.List;

public interface TicketDAO {
    void addTicket(Ticket ticket);
    void updateTicket(Ticket ticket);
    void deleteTicket(int ticketId);
    List<Ticket> getAllTickets();
}