package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import model.Event;

public class EventDAOImpl {
    public void addEvent(Event event) {
    String sql = "INSERT INTO event (event_id, stadium_id, event_name, date, time) VALUES (?, ?, ?, ?, ?)";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, event.getId());
        stmt.setInt(2, event.getStadiumId());
        stmt.setString(3, event.getName());

        // Parse date and time using LocalDate and LocalTime (already standardized in EventForm)
        LocalDate localDate = LocalDate.parse(event.getDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        LocalTime localTime = LocalTime.parse(event.getTime(), DateTimeFormatter.ofPattern("HH:mm:ss"));

        // Convert to java.sql.Date and java.sql.Time for database insertion
        java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
        java.sql.Time sqlTime = java.sql.Time.valueOf(localTime);

        stmt.setDate(4, sqlDate);
        stmt.setTime(5, sqlTime);

        stmt.executeUpdate();
    } catch (SQLException e) {
        throw new RuntimeException("Error adding event: " + e.getMessage(), e);
    }
}

    public void updateEvent(Event event) {
        String sql = "UPDATE event SET stadium_id = ?, event_name = ?, date = ?, time = ? WHERE event_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, event.getStadiumId());
            stmt.setString(2, event.getName());
            stmt.setString(3, event.getDate());
            stmt.setString(4, event.getTime());
            stmt.setInt(5, event.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public void deleteEvent(int eventId) {
        String sql = "DELETE FROM event WHERE event_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            stmt.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT * FROM event";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Event event = new Event(
                    rs.getInt("event_id"),
                    rs.getInt("stadium_id"),
                    rs.getString("event_name"),
                    rs.getString("date"),
                    rs.getString("time")
                );
                events.add(event);
            }
        } catch (SQLException e) {
        }
        return events;
    }

    // New method to fetch all event IDs
    public List<Integer> getAllEventIds() {
        List<Integer> eventIds = new ArrayList<>();
        String sql = "SELECT event_id FROM event";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                eventIds.add(rs.getInt("event_id"));
            }
        } catch (SQLException e) {
        }
        return eventIds;
    }
}