package dao;

import model.Event;
import java.util.List;

public interface EventDAO {
    void addEvent(Event event);
    void updateEvent(Event event);
    void deleteEvent(int eventId);
    List<Event> getAllEvents();
    List<Integer> getAllEventIds();
}